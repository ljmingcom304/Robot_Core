package com.mmednet.klyl;

public interface KLCallback {
	void onBack(String message);
}
