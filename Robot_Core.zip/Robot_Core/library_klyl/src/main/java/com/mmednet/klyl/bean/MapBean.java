package com.mmednet.klyl.bean;

import java.io.Serializable;

public class MapBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4816315169063367902L;
	private String Name;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	

}
