package com.mmednet.klyl.mina;

public interface EventListener {
    public void onEvent(byte cmd, Object obj);
}
