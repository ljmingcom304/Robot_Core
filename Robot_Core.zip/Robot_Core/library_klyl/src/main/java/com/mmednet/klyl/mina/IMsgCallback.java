package com.mmednet.klyl.mina;

public interface IMsgCallback {
	public void receiveMessage(String msg);
}
