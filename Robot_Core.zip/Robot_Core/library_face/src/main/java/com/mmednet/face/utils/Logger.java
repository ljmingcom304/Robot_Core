package com.mmednet.face.utils;

import android.util.Log;

/**
 * Title: Robot_Library
 * <p>
 * Description:
 * </p>
 *
 * @author Zsy
 * @date 2019/3/29 11:46
 */

public class Logger {
    public static void log(String s) {
        Log.i("fffff", s == null ? "null" : s);
    }
}
