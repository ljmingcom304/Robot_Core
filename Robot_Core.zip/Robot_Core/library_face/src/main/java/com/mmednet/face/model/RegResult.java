/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.mmednet.face.model;

@SuppressWarnings("unused")
public class RegResult extends ResponseResult {

}

