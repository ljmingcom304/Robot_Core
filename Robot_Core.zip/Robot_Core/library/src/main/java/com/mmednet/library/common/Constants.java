package com.mmednet.library.common;

public interface Constants {
    String FILE = "file";
    String CACHE = "cache";
    String DATA = "data";
    String CRASH = "crash";
    String INFO = "info";
}
