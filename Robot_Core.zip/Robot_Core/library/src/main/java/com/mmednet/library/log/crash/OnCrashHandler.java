package com.mmednet.library.log.crash;

interface OnCrashHandler {
	 boolean onCrash(Throwable e);
}
