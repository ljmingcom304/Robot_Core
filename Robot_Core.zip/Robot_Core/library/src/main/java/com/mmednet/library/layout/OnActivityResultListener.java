package com.mmednet.library.layout;

import android.content.Intent;

/**
 * Title:OnActivityResultListener
 * <p>
 * Description:
 * </p>
 * Author Jming.L
 * Date 2019/1/17 11:34
 */
public interface OnActivityResultListener {
    void onActivityResult(int requestCode, int resultCode, Intent data);
}
