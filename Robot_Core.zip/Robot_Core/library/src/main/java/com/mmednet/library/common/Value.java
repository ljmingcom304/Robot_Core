package com.mmednet.library.common;

/**
 * Title:Value
 * <p>
 * Description:默认值
 * </p>
 * Author Jming.L
 * Date 2018/6/6 21:49
 */
public interface Value {

    int VALUE_INT = Integer.MIN_VALUE;

}
