package com.mmednet.library.view.dialog;

public interface OnCloseListener {
    void onClose();
}
