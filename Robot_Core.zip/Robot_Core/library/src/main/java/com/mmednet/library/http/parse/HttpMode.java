package com.mmednet.library.http.parse;

public enum HttpMode {
	GET, POST
}
