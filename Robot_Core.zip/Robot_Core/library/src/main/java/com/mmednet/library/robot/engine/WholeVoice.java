package com.mmednet.library.robot.engine;

/**
 * Title:WholeVoice
 * <p>
 * Description:全局语音动作
 * </p>
 * Author Jming.L
 * Date 2017/9/4 17:58
 */
public interface WholeVoice {
}
