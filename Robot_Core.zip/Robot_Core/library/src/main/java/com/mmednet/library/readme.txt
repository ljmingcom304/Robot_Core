compile 'com.android.volley:volley:1.0.0'
compile 'com.google.code.gson:gson:2.4'
compile 'com.j256.ormlite:ormlite-android:5.0'
compile 'com.j256.ormlite:ormlite-core:5.0'
compile 'com.github.promeg:tinypinyin:2.0.3'
compile 'com.github.promeg:tinypinyin-lexicons-android-cncity:2.0.3'
----------------------------------------------------------------------
exclude "**/**/BuildConfig.class"
exclude "**/**/BuildConfig\$*.class"
exclude "**/R.class"
exclude "**/R\$*.class"