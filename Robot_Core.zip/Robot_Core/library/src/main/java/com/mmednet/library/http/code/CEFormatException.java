package com.mmednet.library.http.code;

import java.io.IOException;

class CEFormatException extends IOException {
    private static final long serialVersionUID = -5834182912130197608L;

    public CEFormatException(String var1) {
        super(var1);
    }
}
