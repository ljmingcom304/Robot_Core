package com.mmednet.library.http.code;

import java.io.IOException;

class CEStreamExhausted extends IOException {
    private static final long serialVersionUID = 1514239259098745258L;
}
