package com.mmednet.router.bean;

import com.mmednet.router.BaseBean;


public class RobotBean extends BaseBean {
    private static final long serialVersionUID = 6044948826743091006L;
}
