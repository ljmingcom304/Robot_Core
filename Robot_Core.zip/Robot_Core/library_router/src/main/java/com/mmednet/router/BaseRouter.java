package com.mmednet.router;

/**
 * Title:BaseRouter
 * <p>
 * Description:
 * </p>
 * Author Jming.L
 * Date 2018/6/7 19:00
 */
public class BaseRouter {

    /**
     * 日志实体类
     */
    public static final String LOGGER = "logger";

}
