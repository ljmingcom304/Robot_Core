package com.mmednet.xyzj;

public interface XYCallback {
    void onBack(String message);
}
