package com.mmednet.test;

import org.junit.Test;

/**
 * Example local unit test, which will execute on the development machine (intentHost).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {

    @Test
    public void addition_isCorrect() throws Exception {

    }
}